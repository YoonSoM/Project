_base_ = [
    '/content/mmdetection/1A_my_py/model_FasterRCNN.py',
    '/content/mmdetection/1A_my_py/dataset.py',
    '/content/mmdetection/1A_my_py/schadul.py',
    '/content/mmdetection/1A_my_py/check_point.py'
]